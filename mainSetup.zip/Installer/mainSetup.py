from tkinter import *
import requests
from tkinter import messagebox
import time

s = Tk()
def choice():
	if messagebox.askyesno(title="Warning", message="Are you sure?") == True:
		try:
			url3 = 'https://cs-dev-server.netlify.app/PyTerminal.zip'
			print('Getting Dowland Link..')
			response3 = requests.get(url3)
			print('Dowland link get!')
			filename_app = response3.url[url3.rfind('/')+1:]
			print('Installing file..')
			with open(filename_app, 'wb') as dowland_file:
					for chunk in response3.iter_content(chunk_size=8192):
						if chunk:
							dowland_file.write(chunk)
			messagebox.showinfo(title='Warning',message='File Downloaded.')
		except Exception as e:
			messagebox.showerror(title='Something went wrong!', message=e)
	else:
		s.destroy()
s.geometry("1280x1460")

logo = PhotoImage(file="pyterminal_logo.png")
Label(image=logo).grid(row=1, column=1)
Label(text="SetupDowland").grid(row=1,column=2)
Label(text="").grid(row=2, column=1)
Label(text="").grid(row=3, column=1)
Label(text="").grid(row=4, column=1)
Label(text="""PyTerminal is a Terminal who needs some requirements.
This app is on developing but it will be better when the next versions will be out.
The app needs python and some modules installed.

-------------------------------------------------------------------------

For more informations visit:
pyter-online-official-cs.netlify.app""").grid(row=5,column=1)
Label(text="").grid(row=6, column=1)
Label(text="").grid(row=7, column=1)
Label(text="").grid(row=8, column=1)
Button(text="Dowland Setup", command=choice).grid(row=9, column=1)
s.mainloop()